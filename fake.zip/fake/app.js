import { faker } from "@faker-js/faker";

export const Users = {
  employees: [],
};

export function createRandomUser() {
  return {
    id: faker.datatype.uuid(),
    employeeName: faker.internet.userName(),
    employeeEmail: faker.internet.email(),
    empDob: faker.date.birthdate(),
  };
}

Array.from({ length: 10 }).forEach(() => {
  Users.employees.push(createRandomUser());
});

console.log(JSON.stringify(Users));
